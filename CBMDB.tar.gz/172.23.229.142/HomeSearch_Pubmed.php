<?php

$line=$_GET['new2'];
//echo "EnzymeID:".$line."</br>";
$random = mt_rand(1, 10000);
exec("/data/software/anaconda3/bin/esearch -db pubmed -query \"$line\"  | /data/software/anaconda3/bin/efetch -format medline >> pathwww/filestore/TemPubmed$random.txt");
// $result = file_get_contents("pathwww/filestore/TemPubmed$line.txt");
// echo $result;
// $deresult = json_decode($result);
// echo $deresult;

$handle = fopen("pathwww/filestore/TemPubmed$random.txt", 'r');                 //打开文件

	if (!$handle) {                                     //判断文件是否打开成功

		echo '文件打开失败!';
	}
	while (false !== ($char = fgets($handle,1024))) {        //循环读取文件内容
		echo $char."<br>";
	}
fclose($handle);


