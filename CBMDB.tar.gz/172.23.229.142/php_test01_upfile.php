<?php
//echo "我没有什么问题"."<br>";
$file = $_FILES['upload'];
echo "文件类型:".$file['type']."<br>";
//echo "file['tmp_name']:".$file['tmp_name']."<br>";
//echo "file['name']:".$file['name']."<br>";
if($file['error'] == 0) {
    //将文件存储路径修改掉
    if(move_uploaded_file($file['tmp_name'], "pathwww/filestore/" . $file['name'])) {
        echo 'Upload succeeded'."<br>";
        $filename=$file['name']."<br>";
        //exec("/data/software/anaconda3/bin/blastp  -db /home/www/database/CBMextractresultDB/CBMextractresult -query pathwww/filestore/20211007-CBMSeq_copy.fasta -outfmt 0 -out pathwww/filestore/query02.txt");
        exec("/data/software/anaconda3/bin/blastp  -db /home/www/database/CBMextractresultDB/CBMextractresult -query pathwww/filestore/$filename -outfmt 0 -out pathwww/filestore/query01.txt");
        //passthru("less pathwww/filestore/query02.txt");
        //passthru("less /home/www/test/query.csv");
        } 
    else {
        echo "failed";
        }
}

else {
    echo 'error code:' . $file['error'];
}


//设置允许上传的文件类型
//$allowSuf = array("fasta","txt")
//$SplitName = explode(".",$file["name"]) <iframe src='https://view.officeapps.live.com/op/view.aspx?src=http://ip/www/filestore/query.csv' width='100%' height='100%' frameborder='1'></iframe>

?>

<script>
function readAsText() {
var file = document.getElementById("http://ip/www/filestore/query.csv").files[0];
var reader = new FileReader();
    //将文件以文本形式读入页面
    reader.readAsText(file, "gb2312");
    reader.onload = function () {
        var msg = this.result;
    }
}
</script>