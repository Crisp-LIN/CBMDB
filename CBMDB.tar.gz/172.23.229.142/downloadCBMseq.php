<?php

$CBMfamliy = "CBMFamliy: ".$_GET["CBMFamliy"];
$CBMSourceANDPosition = ",CBMSource AND Position: ".$_GET["CBMSourceANDPosition"]."\n";
$CBMseq = $_GET["CBMSeq"];

$time = time();


$CBM=array($CBMfamliy,$CBMSourceANDPosition,$CBMseq);

$myfile01 = fopen("pathwww/filestore/DownloadSeq_$time.fasta", "w");

$num = count($CBM);

for($i=0;$i<$num;++$i){

    echo $CBM[$i].'<br />';
    fwrite($myfile01,$CBM[$i]);
}

$downloadUrl = 'http://ip/www/filestore/DownloadSeq_'.$time.'.fasta';

echo "<a href='" .$downloadUrl. "' download='.txt'>Download file </a>"."<br>";

?>