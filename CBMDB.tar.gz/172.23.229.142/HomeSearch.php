
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<link rel="profile" href="https://gmpg.org/xfn/11">
<title>Result Page &#8211; Carbohydrate binding module DB</title>
<meta name='robots' content='noindex, nofollow' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="站点标题 &raquo; Feed" href="http://ip/www/mywpproject/feed/" />
<link rel="alternate" type="application/rss+xml" title="站点标题 &raquo; 评论Feed" href="http://ip/www/mywpproject/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/mywpproject\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css'  href='http://ip/www/mywpproject/wp-includes/css/dist/block-library/style.min.css?ver=5.7.2' media='all' />
<link rel='stylesheet' id='hgw-whiteboard-style-css'  href='http://ip/www/mywpproject/wp-content/themes/hgw-whiteboard/style.css?ver=1.0.6' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='http://ip/www/mywpproject/wp-content/themes/hgw-whiteboard/assets/css/fontawesome.css?ver=1.0.6' media='all' />
<link rel="https://api.w.org/" href="http://ip/www/mywpproject/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ip/www/mywpproject/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ip/www/mywpproject/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.2" />

<!--创建一个box显示与收起文本内容，可以设置显示内容部分的大小-->
    <style type="text/css">
    #box 
    {
    width:500px;
    height:200px;
    margin:1px 30px 1px 1px;/*上右下左*/ 
    }
  </style>
<!--/创建一个box显示与收起文本内容-->

<!--创建一个box显示与收起文本内容，可以设置显示内容部分的大小,以下部分为box的JS部分-->
<script type="text/javascript">// 内容的收起与展开
    function show() //函数1
    {
    var box = document.getElementById("box"); //获取id属性值为box的div对象。
    var text = box.innerHTML; //将id属性值为box的div中的内容赋值给text变量。
    var newBox = document.createElement("div"); //创建一个新的对象，"div"。
    var btn = document.createElement("a"); //创建一个新的对象，"a"。
    newBox.innerHTML = text.substring(0,300); //截取长度为20的字符串复制给新创建的div
    btn.innerHTML = text.length > 300 ? "...Show all" : "";//如果整个文章的内容字符串长度超过某个值
     //那么就将”…显示全部”复制给新创建的链接，否则将空值赋值给新创建的链接对象。
    btn.href = "###"; //将新创建链接的href属性值设置为”###”。

        btn.onclick = function() //函数1(1)
        {
        if(btn.innerHTML == "...Show all")
            {
            btn.innerHTML = "fold";
            newBox.innerHTML = text;
            }
        else
            {
            btn.innerHTML = "...Show all";
            newBox.innerHTML = text.substring(0,300);
            }
        }

        box.innerHTML = "";
        box.appendChild(newBox);
        box.appendChild(btn);
    }
    
    window.onload=function()//函数2
    {
    show();
    }
  </script>
<!--/创建一个box显示与收起文本内容，可以设置显示内容部分的大小,以下部分为box的JS部分-->

</head>

<body class="home blog wp-embed-responsive">

  <header id="site-header">
    <a class="skip-link screen-reader-text" href="#site-content">Skip to content</a>
    <div class="brand">
          <div class="col">
            <div class="site-name">
              <a href="http://ip/www/mywpproject/">
                <h1>Result Page</h1>
              </a>
            </div>
            <div class="site-description">
            </div>
          </div>
    </div>

    <div id="header-menu" class="header-menus">
      <button class="button open-menu"><i class="fa fa-bars" aria-hidden="true"></i></button>
      <div class="pas">
        <button class="button close-menu"><i class="fa fa-times" aria-hidden="true"></i></button>
        <div class="site-menu primary-menu-wrapper">
            <ul><li class="cat-item cat-item-1"><a href="http://cbmdb.org.cn/">Home</a>
            </li></ul>
        </div>
          <div class="social-menu">
          </div>
      </div>
    </div>
  </header>

<main id="site-content" class="sitecontent">
	<div class="main-content">
<!--搜索结果页面 主要内容1-->		
<article class="post-1 post type-post status-publish format-standard hentry category-uncategorized" id="post-1">
	<div class="post-inner"><!-- .post-inner -->
		<div class="entry-content"><!-- .entry-content -->
      <h4 class="entry-title"><a href="http://ip/www/mywpproject/2021/06/08/hello-world/">Result Information</a></h4>
      <div class="entry-post-info">
        <div class="entry-taxonomy">
  				    <div class="entry-taxonomy-inner">
            <span class="screen-reader-text">
              <i class="fa fa-list" aria-hidden="true" title="Categories"></i>
            </span>
        <!--<a href="http://ip/www/mywpproject/category/uncategorized/">-->
        <div id='box'>
<?php  
         //接收前端搜索框的输入,数据库连接,数据库内容查询并输出.
        # 接收前端搜索框的输入
            $searchtype=trim($_GET["search"]);
            if(!$searchtype){
                echo"You have not entered search
                details.Please go back and try again.";
                exit;
                }    
            echo "Query:".$searchtype."</br>"."Result"."</br>";
        # /接收前端搜索框的输入 

        # 数据库连接部分
            # 连接数据库所需各项参数,以下参数是正确的。
            $servername = "localhost";
            $username = "root";
            $password = "4jiPM6cMsnH7eG8J";
            $dbname = "CBMINFOandSEQ";
            $port = "3306";
            # 创建连接 (面向过程)
            @$conn = mysqli_connect($servername,$username,$password,$dbname,$port);#加"@"符号，抑制报错信息出现，换成自己的报错信息。
            # 检测连接 (面向过程)
            if (!$conn) {
                die("连接失败。报错信息:" . mysqli_connect_error());
            } 
        # /数据库连接部分

        # 数据库内容查询并输出
            #单引号串和双引号串在PHP中的处理是不相同的。双引号串中的内容可以被解释而且替换，而单引号串中的内容总被认为是普通字符。
            if(strpos($searchtype,'CBM') !== false){
              $sql05 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE CBMFamliy LIKE '$searchtype'";
              $result05 = mysqli_query($conn,$sql05);
             
              $IDArray = array();
              if (mysqli_num_rows($result05) > 0) {
                while($row = mysqli_fetch_assoc($result05)) {
                  $rowwww=ltrim($row["EnzymeID"],">");
                  $enzymeseq=$row["EnzymeSeq"];
                  $enzymetype=$row["EnzymeType"];
                  $speciesorigin=$row["SpeciesOrigin"];
                  $CBMfamily=$row["CBMFamliy"];
                  

                  echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                  ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."CBMFamliy:".$row["CBMFamliy"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                  ."<a href='downloadseq.php?seq=$enzymeseq&new2=$rowwww&enzymetype=$enzymetype&speciesorigin=$speciesorigin&CBMfamily=$CBMfamily'>Download the sequence</a>"."</br>"
                  ."Publication Information:"."<a href='HomeSearch_Pubmed.php?new2=$CBMfamily'>Article</a>"."</br>"."</br>";
                  array_push($IDArray,$row["EnzymeID"]);
                }
              }
            }

            else{
            $sql01 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE EnzymeID LIKE '%$searchtype%'";#查询语句中变量的单引号十分重要
            $sql02 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE EnzymeType LIKE '%$searchtype%'";
            $sql03 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE SpeciesOrigin LIKE '%$searchtype%'";
            $sql04 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE EnzymeSeq LIKE '%$searchtype%'";
            //$sql05 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE CBMFamliy LIKE '$searchtype'";

            $result01 = mysqli_query($conn,$sql01);
            $result02 = mysqli_query($conn,$sql02);
            $result03 = mysqli_query($conn,$sql03);
            $result04 = mysqli_query($conn,$sql04);

            $IDArray = array();

                if (mysqli_num_rows($result01) > 0) {
                  while($row = mysqli_fetch_assoc($result01)) {
                      $rowwww=ltrim($row["EnzymeID"],">");
                      $enzymeseq=$row["EnzymeSeq"];
                      $enzymetype=$row["EnzymeType"];
                      $speciesorigin=$row["SpeciesOrigin"];
                      $CBMfamily=$row["CBMFamliy"];

                      echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                      ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                      ."<a href='downloadseq.php?seq=$enzymeseq&new2=$rowwww&enzymetype=$enzymetype&speciesorigin=$speciesorigin&CBMfamily=$CBMfamily'>Download the sequence</a>"."</br>"
                      ."CBMFamliy:".$row["CBMFamliy"]."</br>"."Publication Information:"."<a href='HomeSearch_Pubmed.php?new2=$CBMfamily'>Article</a>"."</br>"."</br>"; //注意此处! 注意引号位置!!!
                      array_push($IDArray,$row["EnzymeID"]);
                  }
                }
              elseif (mysqli_num_rows($result02) > 0) {
              
                  while($row = mysqli_fetch_assoc($result02)) {
                    $rowwww=ltrim($row["EnzymeID"],">");
                    $enzymeseq=$row["EnzymeSeq"];
                    $enzymetype=$row["EnzymeType"];
                    $speciesorigin=$row["SpeciesOrigin"];
                    $CBMfamily=$row["CBMFamliy"];

                    echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                    ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                    ."<a href='downloadseq.php?seq=$enzymeseq&new2=$rowwww&enzymetype=$enzymetype&speciesorigin=$speciesorigin&CBMfamily=$CBMfamily'>Download the sequence</a>"."</br>"
                    ."CBMFamliy:".$row["CBMFamliy"]."</br>"."Publication Information:"."<a href='HomeSearch_Pubmed.php?new2=$CBMfamily'>Article</a>"."</br>"."</br>";
                    array_push($IDArray,$row["EnzymeID"]);
                  }
              }
              elseif (mysqli_num_rows($result03) > 0) {
                  while($row = mysqli_fetch_assoc($result03)) {
                    $rowwww=ltrim($row["EnzymeID"],">");
                    $enzymeseq=$row["EnzymeSeq"];
                    $enzymetype=$row["EnzymeType"];
                    $speciesorigin=$row["SpeciesOrigin"];
                    $CBMfamily=$row["CBMFamliy"];

                    echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                    ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                    ."<a href='downloadseq.php?seq=$enzymeseq&new2=$rowwww&enzymetype=$enzymetype&speciesorigin=$speciesorigin&CBMfamily=$CBMfamily'>Download the sequence</a>"."</br>"
                    ."CBMFamliy:".$row["CBMFamliy"]."</br>"."Publication Information:"."<a href='HomeSearch_Pubmed.php?new2=$CBMfamily'>Article</a>"."</br>"."</br>";
                    array_push($IDArray,$row["EnzymeID"]);
                  }

              }
              elseif (mysqli_num_rows($result04) > 0) {
                  while($row = mysqli_fetch_assoc($result04)) {
                    $rowwww=ltrim($row["EnzymeID"],">");
                    $enzymeseq=$row["EnzymeSeq"];
                    $enzymetype=$row["EnzymeType"];
                    $speciesorigin=$row["SpeciesOrigin"];
                    $CBMfamily=$row["CBMFamliy"];

                    echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                    ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                    ."<a href='downloadseq.php?seq=$enzymeseq&new2=$rowwww&enzymetype=$enzymetype&speciesorigin=$speciesorigin&CBMfamily=$CBMfamily'>Download the sequence</a>"."</br>"
                    ."CBMFamliy:".$row["CBMFamliy"]."</br>"."Publication Information:"."<a href='HomeSearch_Pubmed.php?new2=$CBMfamily'>Article</a>"."</br>"."</br>";
                    array_push($IDArray,$row["EnzymeID"]);
                  }
              }

              else {
                echo "Sorry, no results found"."</br>";
              }
            }

        # /数据库内容查询并输出
?>
        </div><!--BOX-->

<?php //数据库查询代码1.0
            /*
      {
            if (mysqli_num_rows($result01) > 0) {
                while($row = mysqli_fetch_assoc($result01)) {
                    echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                    ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                    ."CBMFamliy:".$row["CBMFamliy"]."</br>"."</br>";
                    array_push($IDArray,$row["EnzymeID"]);
                }
            }
            elseif (mysqli_num_rows($result02) > 0) {
            
                while($row = mysqli_fetch_assoc($result02)) {
                  echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                  ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                  ."CBMFamliy:".$row["CBMFamliy"]."</br>"."</br>";
                  array_push($IDArray,$row["EnzymeID"]);
                }
            }
            elseif (mysqli_num_rows($result03) > 0) {
                while($row = mysqli_fetch_assoc($result03)) {             
                  echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                  ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                  ."CBMFamliy:".$row["CBMFamliy"]."</br>"."</br>";
                  array_push($IDArray,$row["EnzymeID"]);
                }

            }
            elseif (mysqli_num_rows($result04) > 0) {
                while($row = mysqli_fetch_assoc($result04)) {
                  echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                  ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                  ."CBMFamliy:".$row["CBMFamliy"]."</br>"."</br>";
                  array_push($IDArray,$row["EnzymeID"]);
                }
            }
            elseif (mysqli_num_rows($result05) > 0) {
                while($row = mysqli_fetch_assoc($result05)) {
                  echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                  ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."CBMFamliy:".$row["CBMFamliy"]."</br>"."</br>";
                  //"EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                  array_push($IDArray,$row["EnzymeID"]);
                }
           }
            else {
                echo "Sorry, no results found"."</br>";
            }
           
           # mysqli_close($conn);
           
        }
            */
?>

</a>
</div><!-- .entry-categories-inner -->       
</div>
</div>
<p><!--应该填入内容--></p>

<a class="read-more" href=""></a>
</div><!-- .entry-content -->
</div><!-- .post-inner -->
</article><!-- .post -->


<!--主要内容2-->

<article class="post-1 post type-post status-publish format-standard hentry category-uncategorized" id="post-1">
	<div class="post-inner"><!-- .post-inner -->
		<div class="entry-content"><!-- .entry-content -->
      <h4 class="entry-title">Information about the CBM contained in enzymes</h4>
      <div class="entry-post-info">
        <div class="entry-taxonomy">
  				          <div class="entry-taxonomy-inner">

            <span class="screen-reader-text">
              <i class="fa fa-list" aria-hidden="true" title="Categories"></i>
            </span>
<!--创建一个box显示与收起文本内容，可以设置显示内容部分的大小-->
<style type="text/css">
    #box 
    {
    width:500px;
    height:200px;
    margin:1px 30px 1px 1px;/*上右下左*/ 
    }
  </style>
<!--/创建一个box显示与收起文本内容-->

<!--创建一个box显示与收起文本内容，可以设置显示内容部分的大小,以下部分为box的JS部分-->
<script type="text/javascript">// 内容的收起与展开
    function show() //函数1
    {
    var box = document.getElementById("box"); //获取id属性值为box的div对象。
    var text = box.innerHTML; //将id属性值为box的div中的内容赋值给text变量。
    var newBox = document.createElement("div"); //创建一个新的对象，"div"。
    var btn = document.createElement("a"); //创建一个新的对象，"a"。
    newBox.innerHTML = text.substring(0,300); //截取长度为20的字符串复制给新创建的div
    btn.innerHTML = text.length > 300 ? "...Show all" : "";//如果整个文章的内容字符串长度超过某个值
     //那么就将”…显示全部”复制给新创建的链接，否则将空值赋值给新创建的链接对象。
    btn.href = "###"; //将新创建链接的href属性值设置为”###”。

        btn.onclick = function() //函数1(1)
        {
        if(btn.innerHTML == "...Show all")
            {
            btn.innerHTML = "fold";
            newBox.innerHTML = text;
            }
        else
            {
            btn.innerHTML = "...Show all";
            newBox.innerHTML = text.substring(0,300);
            }
        }

        box.innerHTML = "";
        box.appendChild(newBox);
        box.appendChild(btn);
    }
    
    window.onload=function()//函数2
    {
    show();
    }
  </script>
  <!--/创建一个box显示与收起文本内容，可以设置显示内容部分的大小,以下部分为box的JS部分-->

  <div id=box>     
        <?php
        for ($i=0; $i < count($IDArray); $i++) {
                
            echo $IDArray[$i]."<br/>";
        
            $QID =  $IDArray[$i];           #$ID;
            echo "Query:".ltrim($QID,">")."</br>"."Result"."</br>";
        
            $sql11 = "SELECT DISTINCT * FROM HmmscanCBMSeq WHERE CBMEnzymeID LIKE '%$QID%'";
            $result11 = mysqli_query($conn,$sql11);
            if (mysqli_num_rows($result11) > 0) {
              while($row = mysqli_fetch_assoc($result11)) {
                $row["CBMEnzymeID"] = ltrim($row["CBMEnzymeID"],">");

                $CBMfamliy = $row["CBMFamily"];
                $CBMSourceANDPosition = substr($row["CBMEnzymeID"],0,strpos($row["CBMEnzymeID"], '#'));
                $CBMseq = $row["CBMSeq"];
                
                echo "CBMFamliy:".$row["CBMFamily"]."</br>"
                  ."Source AND Position:".substr($row["CBMEnzymeID"],0,strpos($row["CBMEnzymeID"], '#'))
                  .",".$row["CBMPosition"]."</br>"."CBMSeq:".$row["CBMSeq"]."</br>"
                  ."<a href='downloadCBMseq.php?CBMFamliy=$CBMfamliy&CBMSourceANDPosition=$CBMSourceANDPosition&CBMSeq=$CBMseq'>Download the sequence</a>"."</br>"."</br>";      
                }
            }
            else {
              echo "Sorry, no results found"."</br>";
            }
        }
        mysqli_close($conn);#注意此关闭代码，会导致需要重新连接数据库。

        ?> 
</div id=box>

</a>
</div><!-- .entry-categories-inner -->       
</div>
</div>
<p><!--应该填入内容--></p>

<a class="read-more" href="http://ip/www/mywpproject/2021/06/08/hello-world/"></a>
</div><!-- .entry-content -->
</div><!-- .post-inner -->
</article><!-- .post -->

<!-- 侧边内容
<aside id="sidebar" class="sidebar">
    <div class="sticky">

      
        

      <div id="media_image-4" class="widget widget_media_image"><img width="800" height="600" src="http://ip/www/mywpproject/wp-content/uploads/2021/06/CBM6.jpg" class="image wp-image-72  attachment-full size-full" alt="" loading="lazy" style="max-width: 100%; height: auto;" srcset="http://ip/www/mywpproject/wp-content/uploads/2021/06/CBM6.jpg 800w, http://ip/www/mywpproject/wp-content/uploads/2021/06/CBM6-300x225.jpg 300w, http://ip/www/mywpproject/wp-content/uploads/2021/06/CBM6-768x576.jpg 768w" sizes="(max-width: 800px) 100vw, 800px" /></div><div id="text-8" class="widget widget_text"><h4 class="widget-title">CBM6</h4>			<div class="textwidget"><table class="infobox" style="height: 294px;" width="369">
<tbody>
<tr>
<th class="infobox-header" colspan="2">Identifiers</th>
</tr>
<tr>
<th class="infobox-label" scope="row">Symbol</th>
<td class="infobox-data">CBM_6</td>
</tr>
<tr>
<th class="infobox-label" scope="row"><a title="" href="https://en.wikipedia.org/wiki/Pfam">Pfam</a></th>
<td class="infobox-data pfam"><a class="external text" href="http://pfam.xfam.org/family?acc=PF03422" rel="nofollow">PF03422</a></td>
</tr>
<tr>
<th class="infobox-label" scope="row"><a title="Pfam" href="https://en.wikipedia.org/wiki/Pfam">Pfam</a> clan</th>
<td class="infobox-data"><a class="external text" href="http://pfam.xfam.org/clan/CL0202" rel="nofollow">CL0202</a></td>
</tr>
<tr>
<th class="infobox-label" scope="row"><a title="Cysteine" href="https://en.wikipedia.org/wiki/InterPro">InterPro</a></th>
<td class="infobox-data"><a class="external text" href="https://www.ebi.ac.uk/interpro/entry/IPR005084" rel="nofollow">IPR005084</a></td>
</tr>
<tr>
<th class="infobox-label" scope="row"><a class="mw-redirect" title="Structural Classification of Proteins" href="https://en.wikipedia.org/wiki/Structural_Classification_of_Proteins">SCOP2</a></th>
<td class="infobox-data"><a class="external text" href="http://scop2.mrc-lmb.cam.ac.uk/search?t=txt;q=1gmm" rel="nofollow">1gmm</a> / <a class="external text" href="https://scop.berkeley.edu/pdb/code=1gmm" rel="nofollow">SCOPe</a> / <a class="external text" href="http://supfam.org/SUPERFAMILY/cgi-bin/search.cgi?search_field=1gmm" rel="nofollow">SUPFAM</a></td>
</tr>
<tr>
<th class="infobox-label" scope="row"><a title="CAZy" href="https://en.wikipedia.org/wiki/CAZy">CAZy</a></th>
<td class="infobox-data"><a class="external text" href="http://www.cazy.org/CBM6.html" rel="nofollow">CBM6</a></td>
</tr>
</tbody>
</table>

</div>
		</div>
  </div>
</aside>
-->
<html>

</html>

<html>
</main><!-- #site-content -->
			<footer id="site-footer" class="header-footer-group">
				<div class="section-inner">
						<p class="footer-copyright">
							&copy; 2021
							<a href="http://cbmdb.org.cn/"> National and Local Joint Engineering Laboratory of Biocatalysis Technology  </a>
						</p><!-- .footer-copyright -->

                    <!-- 	<a class="to-the-top" href="#site-header">&uarr;</a>.to-the-top -->
				</div><!-- .section-inner -->
			</footer><!-- #site-footer -->
		<script src='http://ip/www/mywpproject/wp-content/themes/hgw-whiteboard/assets/js/hgw-scripts.js?ver=1.0.6' id='hgw-whiteboard-js-js'></script>
<script src='http://ip/www/mywpproject/wp-includes/js/wp-embed.min.js?ver=5.7.2' id='wp-embed-js'></script>

</body>

</html>
