<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<link rel="profile" href="https://gmpg.org/xfn/11">
<title>Carbohydrate binding module DB &#8211; This is a public database for CBM researchers</title>
<meta name='robots' content='noindex, nofollow' />
        <script type="text/javascript">
            window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/ip/www\/mywpproject\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.2"}};
            !function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
        </script>
        <style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css'  href='http://ip/www/mywpproject/wp-includes/css/dist/block-library/style.min.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-font-css'  href='https://fonts.googleapis.com/css?family=Rajdhani%3A400%2C500%2C700&#038;ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-basic-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/style.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-responsive-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/theme-responsive.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='nivo-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/nivo-slider.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/font-awesome.css?ver=5.7.2' type='text/css' media='all' />
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/jquery.nivo.slider.js?ver=5.7.2' id='jquery-nivo-slider-js-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/custom.js?ver=5.7.2' id='medex-lite-customscripts-js'></script>
<link rel="https://api.w.org/" href="http://ip/www/mywpproject/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ip/www/mywpproject/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ip/www/mywpproject/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.2" />
    <style>
        	.medex-topbar{
        		background-color:#081839;
        	}
			a, 
			.tm_client strong,
			.postmeta a:hover,
			#sidebar ul li a:hover,
			.blog-post h3.entry-title,
			a.blog-more:hover,
			#commentform input#submit,
			input.search-submit,
			.nivo-controlNav a.active,
			.blog-date .date,
			.sitenav ul li.current_page_item a, 
			.sitenav ul li a:hover, 
			.sitenav ul li.current_page_item ul li a:hover,
			.home-banner h4{
				color:#1bbde4;
			}
			.appointment a:hover{
				background-color:#081839;
				color:#1bbde4;
				border-color:#1bbde4;
			}
			.home-banner a.slide-button{
				border-color:#1bbde4;
			}
			h3.widget-title,
			.nav-links .current,
			.nav-links a:hover,
			p.form-submit input[type="submit"],
			.appointment a,
			.home-banner a.slide-button:hover,
			.boxes.odd,
			.intro-content a.intro-more,
			span.toll-free{
				background-color:#1bbde4;
			}
			#header,
			.sitenav ul li.menu-item-has-children:hover > ul,
			.sitenav ul li.menu-item-has-children:focus > ul,
			.sitenav ul li.menu-item-has-children.focus > ul{
				background-color:#ffffff;
			}
			.sitenav ul li a,
			.sitenav ul li.current_page_item ul li a{
				color:#111709;
			}
			.copyright-wrapper{
				background-color:#1bbde4;
			}
			
			/* 修改"选择文件"为英文的CSS部分 */
				label{
					position: relative;
				}
				#btn{
					margin-right: 5px;
				}
				#uploadFile{
					position: absolute;
					left: 0;
					top: 0;
					opacity: 0;
				}
			/* 修改"选择文件"为英文的CSS部分 */

		</style>
		<style type="text/css">
			#header{
			background-image: url();
			background-position: center top;
		}
		.site-title h1 a { color:#1bbde4;}
		
	</style>

    <style>
        <style>
		div{
		    width:2000px;
		    height:2000px;
		    margin:0 auto;
		}
	</style>

    </style>
	</head>

<body class="home blog">
<a class="skip-link screen-reader-text" href="#sitemain">
	Skip to content</a>

<header id="header" class="main-header">
	
	<div class="wrapper">
		<div class="align-content align-center tab-block">
			<div class="col-left">
	<div class="site-title">
					<h1><a href="" rel="home">RESULT</a></h1>
						<p>This is a public database for CBM researchers</p>
			</div>
			<!-- 页面整体布局-->
</div><!-- col-left --><div class="col-right">
	<div class="toggle">
		<a class="toggleMenu" href="#">Menu</a>
	</div><!-- toggle -->
	<nav id="main-navigation" class="site-navigation primary-navigation sitenav" role="navigation">
		<div class="menu-primary-menu-container"><ul id="menu-primary-menu" class="menu"><li id="menu-item-39" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-39"><a href="http://cbmdb.org.cn/" aria-current="page">HOME</a></li>
</ul></div>	</nav>
</div><!-- col-right -->		</div><!-- align content -->
	</div><!-- wrapper -->
	
</header><!-- header -->  <div class="main-container">
    <div class="content-area">
        <div class="middle-align content_sidebar">
            <div class="site-main" id="sitemain">
				<div class="blog-post-repeat">
    <article id="post-1" class="post-1 post type-post status-publish format-standard hentry category-uncategorized">
        <header class="entry-header">

<!--==========网页正文内容==========-->
<h2>
<?php
    $PDBID01 = $_GET['PDB01'];
    $PDBID02 = $_GET['PDB02'];
    //echo $PDBID01."<br>";
    //echo $PDBID02."<br>";


    function pdb_file_download02($PDBID){
		/*
		把用户上传的PDB ID写入到一个文件中,根据这个文件中的PDBid，通过脚本batch_download.sh，下载PDB文件
		*/
        echo $PDBID."<br>";
        $pdb_list_file = fopen("pathwww/test01/PDBfileTem/PDBIDList_$PDBID.txt", "w");
        fwrite($pdb_list_file,$PDBID);
        exec("pathwww/filestore/pdbfile/batch_download.sh -f pathwww/test01/PDBfileTem/PDBIDList_$PDBID.txt  -p  -o pathwww/filestore/pdbfile");
        //$downloadUrl = 'http://ip/www/filestore/pdbfile/'.$PDBID.'.pdb.gz';
        //echo "<a href='" .$downloadUrl. "' download='.pdb.gz'>Download PDB format file of protein structure</a>"."<br>";
    }

    pdb_file_download02($PDBID01);
    pdb_file_download02($PDBID02);
    
    exec("gunzip pathwww/filestore/pdbfile/".$PDBID01.".pdb.gz");
    exec("gunzip pathwww/filestore/pdbfile/".$PDBID02.".pdb.gz");

    //exec("mv pathwww/filestore/pdbfile/".$PDBID01.".pdb pathwww/filestore/pdbfile/".$PDBID02.".pdb pathwww/test01/PDBfileTem");
    passthru("/data/software/FATCAT_software/FATCATMain/FATCAT -i pathwww/filestore/pdbfile -p1 $PDBID01.pdb -p2 $PDBID02.pdb -o pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02." -m -ac -t -s");
	//passthru("cat pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02.".aln");
	echo "<br>";
	@$handle = fopen("pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02.".aln", 'r');                 //打开文件

	if (!$handle) {                                     //判断文件是否打开成功

		echo 'File open failure!';

	}

	else {
		while (false !== ($char = fgets($handle,1024))) {        //循环读取文件内容

		echo $char."<br>";
		//$res = preg_match("/^\.*/",$char); 正则表达式使用教程
		if(substr($char,0,1) === "\n"){
			break;
		}
	}
	fclose($handle);
}

	     

    exec("zip -q -j -m pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02.".zip pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02.".*");
	#exec("rm pathwww/filestore/pdbfile/*pdb*");
	
    //echo "zip -q pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02.".zip pathwww/filestore/pdbfile/".$PDBID01."_".$PDBID02.".*";
            
    $downloadUrl = 'http://ip/www/filestore/pdbfile/'.$PDBID01."_".$PDBID02.'.zip';
    echo "<a href='" .$downloadUrl. "' download='.zip'>Download result of protein structure alignment</a>"."<br>";
            
?>
</h2>
    

            </div>
            
            
            
            </body>
            </p>
    <!--==========/网页正文内容==========-->
</html>
                            <div class="postmeta">
                    <div class="post-comment"> <i class="fa fa-comments-o" aria-hidden="true"></i> <a href="">About us</a></div>
            
                    <div class="clear"></div>
                    
                </div><!-- postmeta -->
            	        	            <div class="post-thumb">	                    </div><!-- post-thumb -->
        </header><!-- .entry-header -->
                    
                    <div class="entry-summary">
                <p><b></b></p>
                
            </article><!-- #post-## -->
    <div class="spacer20"></div>
</div><!-- blog-post-repeat -->            </div>

            <div id="sidebar">
    
    <aside id="search-2" class="widget widget_search"><form role="search" method="get" class="search-form" action="http://ip/www/mywpproject/">
	<label>
		<input type="search" class="search-field" placeholder="Search..." value="" name="s">
	</label>
	<input type="submit" class="search-submit" value="Search">
</form>
    </aside>

</div><!-- sidebar -->
            <div class="clear"></div>
        </div>
    </div>

</div>
<!--========底部版权========-->

    <!DOCTYPE html>


    <div class="copyright-wrapper">
    	<div class="wrapper">
            <div class="copyright">
                <p><a href="" rel="home">© 2021 National and local Joint Engineering Laboratory of Biocatalysis Technology </p>               
            </div><!-- copyright --><div class="clear"></div>           
        </div><!-- container -->
    </div>
</div>
        
<script type='text/javascript' id='medex-lite-navigation-js-extra'>
/* <![CDATA[ */
var NavigationScreenReaderText = [];
/* ]]> */
</script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/navigation.js?ver=20190715' id='medex-lite-navigation-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/wp-embed.min.js?ver=5.7.2' id='wp-embed-js'></script>
<!--========/底部版权========-->

</body>
</html>

