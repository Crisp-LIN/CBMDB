sed -i '/Database: User specified sequence set (Input:/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/\/www\/wwwroot\//d' pathwww/filestore/PairwiseResult01.txt
sed -i '/1 sequences;/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/BLASTP 2.9.0+/,/>/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/Length=/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/Effective search space used:/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/Posted date:/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/Number of letters in database:/d' pathwww/filestore/PairwiseResult01.txt
sed -i '/Number of sequences in database:/d' pathwww/filestore/PairwiseResult01.txt 
