<?php
$enzymeID=$_GET['new2'];
//echo "EnzymeID:".$enzymeID."</br>";
$C_enzymeID= '>'.$enzymeID;

$Seq=$_GET['seq']."\n";
//echo "SEQ:".$line."</br>";
$enzymetype=',Enzymetype: '.$_GET['enzymetype'];
$speciesorigin=',species: '.$_GET['speciesorigin'];
$CBMfamily=',CBMfamily: '.$_GET['CBMfamily']."\n";

$EnzymeIDAndSeq=array($C_enzymeID,$enzymetype,$speciesorigin,$CBMfamily,$Seq);

$myfile01 = fopen("pathwww/filestore/DownloadEnzymeSeq_$enzymeID.fasta", "w");

$num = count($EnzymeIDAndSeq);

for($i=0;$i<$num;++$i){

    echo $EnzymeIDAndSeq[$i].'<br />';
    fwrite($myfile01,$EnzymeIDAndSeq[$i]);
}

$downloadUrl = 'http://ip/www/filestore/DownloadEnzymeSeq_'.$enzymeID.'.fasta';

echo "<a href='" .$downloadUrl. "' download='.fasta'>Download file </a>"."<br>";

?>