
<!DOCTYPE html>
<html lang="zh-CN">
<style>a{TEXT-DECORATION:none}</style>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<link rel="profile" href="https://gmpg.org/xfn/11">
<title>Carbohydrate binding module DB &#8211; This is a public database for CBM researchers</title>
<meta name='robots' content='noindex, nofollow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="站点标题 &raquo; Feed" href="http://ip/www/mywpproject/feed/" />
<link rel="alternate" type="application/rss+xml" title="站点标题 &raquo; 评论Feed" href="http://ip/www/mywpproject/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/ip/www\/mywpproject\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://ip/www/mywpproject/wp-includes/css/dist/block-library/style.min.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-font-css'  href='https://fonts.googleapis.com/css?family=Rajdhani%3A400%2C500%2C700&#038;ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-basic-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/style.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-responsive-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/theme-responsive.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='nivo-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/nivo-slider.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/font-awesome.css?ver=5.7.2' type='text/css' media='all' />
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/jquery.nivo.slider.js?ver=5.7.2' id='jquery-nivo-slider-js-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/custom.js?ver=5.7.2' id='medex-lite-customscripts-js'></script>
<link rel="https://api.w.org/" href="http://ip/www/mywpproject/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ip/www/mywpproject/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ip/www/mywpproject/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.2" />
        <style>
        	.medex-topbar{
        		background-color:#081839;
        	}
			a, 
			.tm_client strong,
			.postmeta a:hover,
			#sidebar ul li a:hover,
			.blog-post h3.entry-title,
			a.blog-more:hover,
			#commentform input#submit,
			input.search-submit,
			.nivo-controlNav a.active,
			.blog-date .date,
			.sitenav ul li.current_page_item a, 
			.sitenav ul li a:hover, 
			.sitenav ul li.current_page_item ul li a:hover,
			.home-banner h4{
				color:#1bbde4;
			}
			.appointment a:hover{
				background-color:#081839;
				color:#1bbde4;
				border-color:#1bbde4;
			}
			.home-banner a.slide-button{
				border-color:#1bbde4;
			}
			h3.widget-title,
			.nav-links .current,
			.nav-links a:hover,
			p.form-submit input[type="submit"],
			.appointment a,
			.home-banner a.slide-button:hover,
			.boxes.odd,
			.intro-content a.intro-more,
			span.toll-free{
				background-color:#1bbde4;
			}
			#header,
			.sitenav ul li.menu-item-has-children:hover > ul,
			.sitenav ul li.menu-item-has-children:focus > ul,
			.sitenav ul li.menu-item-has-children.focus > ul{
				background-color:#ffffff;
			}
			.sitenav ul li a,
			.sitenav ul li.current_page_item ul li a{
				color:#111709;
			}
			.copyright-wrapper{
				background-color:#1bbde4;
			}
				
		</style>
		<style type="text/css">
			#header{
			background-image: url();
			background-position: center top;
		}
		.site-title h1 a { color:#1bbde4;}
		
	</style>
	</head>

<body class="home blog">
<?php
//session_destroy();
//session_start();
function counter($f_value)
 {
      //用w模式打开文件时会清空里面的内容，所以先用r模式打开，取出文件内容，保存到变量
      $fp = fopen($f_value,'r') or die('打开文件时出错。');
      $countNum = fgets($fp,1024);
      fclose($fp);
      $countNum += 1;
	  //$count_modify = $countNum-1;
      $fpw = fopen($f_value,'w');
      fwrite($fpw,$countNum);
      fclose($fpw);
	  
 }
 
     //注释下面一行可以实现同一IP登录不累加效果，测试时可以打开
    //session_destroy();
    //session_start();    //定义session，同一IP登录不累加
    $filepath = 'count.txt';    //count.txt 统计次数
    $_SESSION['temp'] = '';
    if($_SESSION['temp'] == ''){    //判断$_SESSION[temp]的值是否为空,其中的temp为自定义的变量
        if (!file_exists($filepath)){
            //检查文件是否存在，不存在刚新建该文件并赋值为0
              $fp = fopen($filepath,'w');
              fwrite($fp,0);
              fclose($fp);
              counter($filepath);
         }
        else{
              counter($filepath);
         }
        $_SESSION['temp'] = 1;    //登录以后,给$_SESSION[temp]赋一个值1
        }

?>


<a class="skip-link screen-reader-text" href="#sitemain">
	Skip to content</a>


	
	<div class="wrapper">
		<div class="align-content align-center tab-block">
			<div class="col-left">
	<div class="site-title">
					<h1><a href="http://cbmdb.org.cn/" rel="home">Carbohydrate binding module DB</a></h1>
						<p>This is a public database for CBM researchers</p>
			</div><!-- site title -->
</div><!-- col-left --><div class="col-right">
	<div class="toggle">
		<a class="toggleMenu" href="#">Menu</a>
	</div><!-- toggle -->
	<nav id="main-navigation" class="site-navigation primary-navigation sitenav" role="navigation">
		<div class="menu-primary-menu-container"><ul id="menu-primary-menu" class="menu"><li id="menu-item-39" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-39"><a href="http://cbmdb.org.cn/" aria-current="page">HOME</a></li>
</ul></div>	</nav>
</div><!-- col-right -->		</div><!-- align content -->
	</div><!-- wrapper -->
	
 <div class="main-container">
    <div class="content-area">
        <div class="middle-align content_sidebar">
            <div class="site-main" id="sitemain">
				<div class="blog-post-repeat">
    <article id="post-1" class="post-1 post type-post status-publish format-standard hentry category-uncategorized">
     <!--   <header class="entry-header"> -->
            <h2 class="entry-title"><a href="#" rel="bookmark">Hello!</a></h2>
			
                            <div class="postmeta">
                    <div class="post-comment"> <i class="fa fa-comments-o" aria-hidden="true"></i> <a href="http://biotech.dep.dlpu.edu.cn/">About us</a></div>
            
                    <div class="clear"></div>
                </div><!-- postmeta -->
            	        	            <div class="post-thumb">	                    </div><!-- post-thumb -->
    <!--    </header> .entry-header -->
    
                    <div class="entry-summary">
                <p><b>What is CBM?</b></p>
		
	<div class="site-title">
				<p>Carbohydrate-binding module (CBM) is a class of non-catalytically polypeptide modules with a discreet fold present in carbohydrate-active enzymes and playing an essential role in carbohydrate-binding activity due to its proximity effect, targeting function, and disruptive function. To date, CBMs are classified into at least 89 families. Moreover, CBMs can specifically target and discriminate substrates with subtle structural differences. Therefore, collecting and integrating comprehensive information on CBMs provides the basis for the development of CBMs in numerous biotechnological applications.
				</p>
			

            </div><!-- .entry-summary -->
            </article><!-- #post-## -->
    <div class="spacer20"></div>
</div><!-- blog-post-repeat -->            </div>
            <div id="sidebar">
    <!-- 搜索数据库部分-->
    <aside id="search-2" class="widget widget_search"><form role="search" method="get" class="search-form" action="HomeSearch.php" target="_blank"> <!-- 搜索功能位置,不要忘记加后缀，此行加入target标签可在点击后新打开一个标签页-->
	<aside id="text-5" class="widget widget_text"><div id="myDiv"></div><button type="button" onclick="loadXMLDoc()">What keywords can I enter?</button>
	<label>
		<input type="search" class="search-field" placeholder="Search..." value="" name="search" >
	</label>
	<input type="submit" class="search-submit" value="Search" >
</form>

<script>
	function loadXMLDoc(){
		window.alert("You can enter the amino acid sequence, GenbankAccession Number of carbohydrate active enzymes, types of enzymes, organism, and CBM family for search.");
	}
</script>
    <!-- 搜索数据库部分结束-->

</aside>
		</aside><aside id="text-4" class="widget widget_text"><h3 class="widget-title"><a class="widget-title" href="http://cbmdb.org.cn/UserGuide.html"><font color=#FFFFFF>USER GUIDE</font></a></h3><div class="textwidget"></div>
	<!--	<aside id="text-3" class="widget widget_text"><h3 class="widget-title"><a class="widget-title" href="http://cbmdb.org.cn/UserGuide.html">USER GUIDE</a></h3><div class="textwidget"></div>	-->
		</aside><aside id="text-4" class="widget widget_text"><h3 class="widget-title"><a class="widget-title" href="http://cbmdb.org.cn/AlignTest01.html"><font color=#FFFFFF>UPLOAD</font></a></h3><div class="textwidget"></div>
		</aside><aside id="text-5" class="widget widget_text"><div class="textwidget"></div>
		<!-- </aside><aside id="text-6" class="widget widget_text"><h3 class="widget-title"></h3>			<div class="textwidget"></div> -->
		</aside>

		<?php
			echo '<p class="entry-title"> The website has been visited '.file_get_contents($filepath).'</font>th time </p>';
			?>
</div><!-- sidebar -->
            <div class="clear"></div>
        </div>
    </div>

</div><!-- main-container -->

    <div class="copyright-wrapper">
    	<div class="wrapper">
            <div class="copyright">
                <p><a href="http://ip/www/mywpproject/" rel="home">© 2021 School of Biological Engineering, Dalian Polytechnic University</p>               
            </div><!-- copyright --><div class="clear"></div>           
        </div><!-- container -->
    </div>
</div>
        
<script type='text/javascript' id='medex-lite-navigation-js-extra'>
/* <![CDATA[ */
var NavigationScreenReaderText = [];
/* ]]> */
</script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/navigation.js?ver=20190715' id='medex-lite-navigation-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/wp-embed.min.js?ver=5.7.2' id='wp-embed-js'></script>

</body>
</html>
