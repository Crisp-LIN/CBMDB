
<!DOCTYPE html>
<html lang="zh-CN">
<style>a{TEXT-DECORATION:none}</style>
<head>
<!--meta标签:描述HTML文档的元数据-->
<meta name="keywords" content="CBM,carbohydrate-active enzymes,carbohydrate-binding module,CAZy">
<meta charset="UTF-8"> 
<meta name="viewport" content="width=device-width"> <!--针对移动设备优化网页显示-->
<meta name="description" content="A public database for carbohydrate-binding module researchers">
<meta name="author" content="Linx">
<!-- <meta name='robots' content='noindex, nofollow' /> 网站上有些页面不希望被搜索引擎收录，我们可以使用robots的文件或者meta robots 标签。-->
<title>Carbohydrate binding module DB &#8211; This is a public database for CBM researchers</title>
<!-- 此元素只能存在于head部分,不过它可出现任何次数. rel参数必需,定义当前文档与被链接文档之间的关系。rel 是 relationship的英文缩写。-->
<link rel="profile" href="https://gmpg.org/xfn/11">
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="站点标题 &raquo; Feed" href="http://ip/www/mywpproject/feed/" />
<link rel="alternate" type="application/rss+xml" title="站点标题 &raquo; 评论Feed" href="http://ip/www/mywpproject/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/ip/www\/mywpproject\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.2"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css' href='http://ip/www/mywpproject/wp-includes/css/dist/block-library/style.min.css?ver=5.7.2' type='text/css' media='all' />
	<!-- rel='stylesheet' 关联到一个stylesheet（样式表单)-->
<link rel='stylesheet' id='medex-lite-font-css'  href='https://fonts.googleapis.com/css?family=Rajdhani%3A400%2C500%2C700&#038;ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-basic-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/style.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='medex-lite-responsive-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/theme-responsive.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='nivo-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/nivo-slider.css?ver=5.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-style-css'  href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/font-awesome.css?ver=5.7.2' type='text/css' media='all' />
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/jquery.nivo.slider.js?ver=5.7.2' id='jquery-nivo-slider-js-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/custom.js?ver=5.7.2' id='medex-lite-customscripts-js'></script>
<link rel="https://api.w.org/" href="http://ip/www/mywpproject/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ip/www/mywpproject/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ip/www/mywpproject/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7.2" />
        <style>
        	.medex-topbar{
        		background-color:#081839;
        	}
			a, 
			.tm_client strong,
			.postmeta a:hover,
			#sidebar ul li a:hover,
			.blog-post h3.entry-title,
			a.blog-more:hover,
			#commentform input#submit,
			input.search-submit,
			.nivo-controlNav a.active,
			.blog-date .date,
			.sitenav ul li.current_page_item a, 
			.sitenav ul li a:hover, 
			.sitenav ul li.current_page_item ul li a:hover,
			.home-banner h4{
				color:#1bbde4;
			}
			.appointment a:hover{
				background-color:#081839;
				color:#1bbde4;
				border-color:#1bbde4;
			}
			.home-banner a.slide-button{
				border-color:#1bbde4;
			}
			h3.widget-title,
			.nav-links .current,
			.nav-links a:hover,
			p.form-submit input[type="submit"],
			.appointment a,
			.home-banner a.slide-button:hover,
			.boxes.odd,
			.intro-content a.intro-more,
			span.toll-free{
				background-color:#1bbde4;
			}
			#header,
			.sitenav ul li.menu-item-has-children:hover > ul,
			.sitenav ul li.menu-item-has-children:focus > ul,
			.sitenav ul li.menu-item-has-children.focus > ul{
				background-color:#ffffff;
			}
			.sitenav ul li a,
			.sitenav ul li.current_page_item ul li a{
				color:#111709;
			}
			.copyright-wrapper{
				background-color:#1bbde4;
			}
				
		</style>
		<style type="text/css">
			#header{
			background-image: url();
			background-position: center top;
		}
		.site-title h1 a { color:#1bbde4;}
		</style>
</head>

<body class="home blog">
<a class="skip-link screen-reader-text" href="#sitemain">
	Skip to content</a>

<header id="header" class="main-header">
	
	<div class="wrapper">
		<div class="align-content align-center tab-block">
			<div class="col-left">
	<div class="site-title">
					<h1><a href="http://cbmdb.org.cn/" rel="home">Carbohydrate binding module DB</a></h1>
						<p>This is a public database for CBM researchers</p>
			</div><!-- site title -->
</div><!-- col-left --><div class="col-right">
	<div class="toggle">
		<a class="toggleMenu" href="#">Menu</a>
	</div><!-- toggle -->
	<nav id="main-navigation" class="site-navigation primary-navigation sitenav" role="navigation">
		<div class="menu-primary-menu-container"><ul id="menu-primary-menu" class="menu"><li id="menu-item-39" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-39"><a href="http://cbmdb.org.cn/HomePage_test_2.0.html" aria-current="page">HOME</a></li>
</ul></div>	</nav>
</div><!-- col-right -->		</div><!-- align content -->
	</div><!-- wrapper -->
	
</header><!-- header -->  <div class="main-container">

<!--搜索结果页面 主要内容1-->

<!-- <article class="post-1 post type-post status-publish format-standard hentry category-uncategorized" id="post-1">
<h4 class="entry-title"><a href="#">Result Information</a></h4> -->


 

<div class="container mt-3">
<?php //接收前端搜索框的输入,数据库连接,数据库内容查询并输出.
        # 接收前端搜索框的输入
            $searchtype=trim($_GET["search"]);
            if(!$searchtype){
                echo"You have not entered search
                details.Please go back and try again.";
                exit;
                }    
        # /接收前端搜索框的输入 

        # 数据库连接部分
            # 连接数据库所需各项参数,以下参数是正确的。
            $servername = "localhost";
            $username = "root";
            $password = "4jiPM6cMsnH7eG8J";
            $dbname = "CBMINFOandSEQ";
            $port = "3306";
            # 创建连接 (面向过程)
            @$conn = mysqli_connect($servername,$username,$password,$dbname,$port);#加"@"符号，抑制报错信息出现，换成自己的报错信息。
            # 检测连接 (面向过程)
            if (!$conn) {
                die("连接失败。报错信息:" . mysqli_connect_error());
            } 
        # /数据库连接部分

        # 数据库内容查询并输出
            #单引号串和双引号串在PHP中的处理是不相同的。双引号串中的内容可以被解释而且替换，而单引号串中的内容总被认为是普通字符。
            if(strpos($searchtype,'CBM') !== false){
              $sql05 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE CBMFamliy LIKE '$searchtype'";
              $result05 = mysqli_query($conn,$sql05);
             
              $IDArray = array();
              if (mysqli_num_rows($result05) > 0) {
                while($row = mysqli_fetch_assoc($result05)) {
                  echo "EnzymeID:".ltrim($row["EnzymeID"],">")."</br>"."EnzymeType:".$row["EnzymeType"]."<br>"
                  ."SpeciesOrigin:".$row["SpeciesOrigin"]."</br>"."CBMFamliy:".$row["CBMFamliy"]."</br>"."</br>";
                  //"EnzymeSeq:".$row["EnzymeSeq"]."</br>"
                  array_push($IDArray,$row["EnzymeID"]);
                }
              }
            }

            else{
            $sql01 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE EnzymeID LIKE '%$searchtype%'";#查询语句中变量的单引号十分重要
            $sql02 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE EnzymeType LIKE '%$searchtype%'";
            $sql03 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE SpeciesOrigin LIKE '%$searchtype%'";
            $sql04 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE EnzymeSeq LIKE '%$searchtype%'";
            //$sql05 = "SELECT DISTINCT * FROM CBMOriINFOandSEQ WHERE CBMFamliy LIKE '$searchtype'";

            $result01 = mysqli_query($conn,$sql01);
            $result02 = mysqli_query($conn,$sql02);
            $result03 = mysqli_query($conn,$sql03);
            $result04 = mysqli_query($conn,$sql04);

            $IDArray = array();
            echo "
            <html>
            <head>
              <meta charset='utf-8'>
              <meta name='viewport' content='width=device-width, initial-scale=1'>
              <link href='https://cdn.staticfile.org/twitter-bootstrap/5.1.1/css/bootstrap.min.css' rel='stylesheet'>
              <script src='https://cdn.staticfile.org/twitter-bootstrap/5.1.1/js/bootstrap.bundle.min.js'></script>
            </head>
            <body>
                  <div class='container mt-3'>
                  <h4>Query:".$searchtype."</br>"."Result"."</br></h4>
                      <table>
                      <tr>
                              <tr>
                                <th width='10%'>EnzymeID</th> 
                                <th width='20%'>EnzymeType</th>
                                <th width='20%'>SpeciesOrigin</th>
                                <th width='10%'>EnzymeSeq</th>
                                <th width='10%'>CBMFamliy</th>
                              </tr>";
                if (mysqli_num_rows($result01) > 0) {
                  while($row = mysqli_fetch_assoc($result01)) {
                      
                      echo    "
                              <tr class='ResultTable'>
                                <td class='ResultTable'>".ltrim($row["EnzymeID"],">")."</td>
                                <td class='ResultTable'>".$row["EnzymeType"]."</td>
                                <td class='ResultTable'>".$row["SpeciesOrigin"]."</td>
                                <td class='ResultTable'><a href='#'>FASTA</a></td>  
                                <td class='ResultTable'>".$row["CBMFamliy"]."</td>
                              </div>
                              ";
                              //<td>".$row["EnzymeSeq"]."</td>
                  }
                }
            }

?>

        
<script type='text/javascript' id='medex-lite-navigation-js-extra'>
/* <![CDATA[ */
var NavigationScreenReaderText = [];
/* ]]> */
</script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/navigation.js?ver=20190715' id='medex-lite-navigation-js'></script>
<script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/wp-embed.min.js?ver=5.7.2' id='wp-embed-js'></script>

</body>
</html>

