<?php
    
    //exec("/data/software/anaconda3/bin/blastp  -db /home/www/database/CBMextractresultDB/CBMextractresult -query pathwww/filestore/submit01.fasta -outfmt 7 -out pathwww/filestore/submitout01.txt");
    $seq = exec("sed -n '2p' pathwww/filestore/submit01.fasta");
    //echo "序列显示在这里:".$seq."<br>";
    $uniurl = "https://search.rcsb.org/rcsbsearch/v1/query?json=";
    $queryurl = "{\"query\":{\"type\":\"terminal\",\"service\":\"sequence\",\"parameters\":{\"evalue_cutoff\":1,\"identity_cutoff\":0.01,\"target\":\"pdb_protein_sequence\",\"value\":\"".$seq."\"}},\"request_options\":{\"scoring_strategy\":\"sequence\"},\"return_type\":\"polymer_entity\"}";   
    $EncodeQueryUrl = urlencode($queryurl);
    $LastUrl = $uniurl.$EncodeQueryUrl; 
    //echo "lasturl".$LastUrl."<br>";
    function curl_file_get_contents($durl){ 

        //curl方式访问URL

        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, $durl); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 获取数据返回   
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, true); // 在启用 CURLOPT_RETURNTRANSFER 时候将获取数据返回 
        $r = curl_exec($ch); 
        curl_close($ch); 
        return $r; 
    }

    $urlContent = curl_file_get_contents($LastUrl);
    //echo "urlContent:".$urlContent."<br>"."<br>";

    $shuzu = json_decode($urlContent, true);
    //echo $shuzu["result_set"][0]["identifier"];
    @$PDBID01 =  explode("_",$shuzu["result_set"][0]["identifier"]); //修剪字符串
    //echo $PDBID01[0];
    function pdb_file_download($PDBID){
        echo $PDBID.".pdb"."<br>";
        $pdb_list_file = fopen("pathwww/filestore/pdbfile/PDB_".$PDBID.".txt", "w");
        fwrite($pdb_list_file,$PDBID);
        
        exec("pathwww/filestore/pdbfile/batch_download.sh -f pathwww/filestore/pdbfile/PDB_".$PDBID.".txt -p -o pathwww/filestore/pdbfile/");
        $downloadUrl = 'http://ip/www/filestore/pdbfile/'.$PDBID.'.pdb.gz';

        echo "<a href='" .$downloadUrl. "' download='.pdb.gz'>Download PDB format file of protein structure</a>"."<br>";
    }

    
    pdb_file_download($PDBID01[0]);
?>