<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <title>Carbohydrate binding module DB &#8211; This is a public database for CBM researchers</title>
    <meta name='robots' content='noindex, nofollow' />
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "http:\/\/ip/www\/mywpproject\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.2"
            }
        };
        ! function(e, a, t) {
            var n, r, o, i = a.createElement("canvas"),
                p = i.getContext && i.getContext("2d");

            function s(e, t) {
                var a = String.fromCharCode;
                p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, e), 0, 0);
                e = i.toDataURL();
                return p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, t), 0, 0), e === i.toDataURL()
            }

            function c(e) {
                var t = a.createElement("script");
                t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
            }
            for (o = Array("flag", "emoji"), t.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, r = 0; r < o.length; r++) t.supports[o[r]] = function(e) {
                if (!p || !p.fillText) return !1;
                switch (p.textBaseline = "top", p.font = "600 32px Arial", e) {
                    case "flag":
                        return s([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) ? !1 : !s([55356, 56826, 55356, 56819], [55356, 56826, 8203, 55356, 56819]) && !s([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421, 56128, 56430, 56128, 56423, 56128, 56447], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447]);
                    case "emoji":
                        return !s([55357, 56424, 8205, 55356, 57212], [55357, 56424, 8203, 55356, 57212])
                }
                return !1
            }(o[r]), t.supports.everything = t.supports.everything && t.supports[o[r]], "flag" !== o[r] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[o[r]]);
            t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t.readyCallback = function() {
                t.DOMReady = !0
            }, t.supports.everything || (n = function() {
                t.readyCallback()
            }, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
                "complete" === a.readyState && t.readyCallback()
            })), (n = t.source || {}).concatemoji ? c(n.concatemoji) : n.wpemoji && n.twemoji && (c(n.twemoji), c(n.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='wp-block-library-css' href='http://ip/www/mywpproject/wp-includes/css/dist/block-library/style.min.css?ver=5.7.2' type='text/css' media='all' />
    <link rel='stylesheet' id='medex-lite-font-css' href='https://fonts.googleapis.com/css?family=Rajdhani%3A400%2C500%2C700&#038;ver=5.7.2' type='text/css' media='all' />
    <link rel='stylesheet' id='medex-lite-basic-style-css' href='http://ip/www/mywpproject/wp-content/themes/medex-lite/style.css?ver=5.7.2' type='text/css' media='all' />
    <link rel='stylesheet' id='medex-lite-responsive-style-css' href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/theme-responsive.css?ver=5.7.2' type='text/css' media='all' />
    <link rel='stylesheet' id='nivo-style-css' href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/nivo-slider.css?ver=5.7.2' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-style-css' href='http://ip/www/mywpproject/wp-content/themes/medex-lite/css/font-awesome.css?ver=5.7.2' type='text/css' media='all' />
    <script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
    <script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
    <script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/jquery.nivo.slider.js?ver=5.7.2' id='jquery-nivo-slider-js-js'></script>
    <script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/custom.js?ver=5.7.2' id='medex-lite-customscripts-js'></script>
    <link rel="https://api.w.org/" href="http://ip/www/mywpproject/wp-json/" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ip/www/mywpproject/xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ip/www/mywpproject/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.7.2" />
    <style>
        .medex-topbar {
            background-color: #081839;
        }

        a,
        .tm_client strong,
        .postmeta a:hover,
        #sidebar ul li a:hover,
        .blog-post h3.entry-title,
        a.blog-more:hover,
        #commentform input#submit,
        input.search-submit,
        .nivo-controlNav a.active,
        .blog-date .date,
        .sitenav ul li.current_page_item a,
        .sitenav ul li a:hover,
        .sitenav ul li.current_page_item ul li a:hover,
        .home-banner h4 {
            color: #1bbde4;
        }

        .appointment a:hover {
            background-color: #081839;
            color: #1bbde4;
            border-color: #1bbde4;
        }

        .home-banner a.slide-button {
            border-color: #1bbde4;
        }

        h3.widget-title,
        .nav-links .current,
        .nav-links a:hover,
        p.form-submit input[type="submit"],
        .appointment a,
        .home-banner a.slide-button:hover,
        .boxes.odd,
        .intro-content a.intro-more,
        span.toll-free {
            background-color: #1bbde4;
        }

        #header,
        .sitenav ul li.menu-item-has-children:hover>ul,
        .sitenav ul li.menu-item-has-children:focus>ul,
        .sitenav ul li.menu-item-has-children.focus>ul {
            background-color: #ffffff;
        }

        .sitenav ul li a,
        .sitenav ul li.current_page_item ul li a {
            color: #111709;
        }

        div.copyright-wrapper {
            background-color: #1bbde4;
            left: 0;
            bottom: 0;
            position: relative;
        }

        /* 修改"选择文件"为英文的CSS部分 */
        label {
            position: relative;
        }

        #btn {
            margin-right: 5px;
        }

        #uploadFile {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
        }

        /* 修改"选择文件"为英文的CSS部分 */
    </style>
    <style type="text/css">
        #header {
            background-image: url();
            background-position: center top;
        }

        .site-title h1 a {
            color: #1bbde4;
        }
    </style>
    <style>
        /* 自己写的style */ 
        div.result_table {
            padding-right: 10px;
            padding-left: 10px;
        }

        myIframe {
            font-size: 550px;
        }
    </style>


    <?php
    /* 集中存放php函数 */

    function curl_file_get_contents($durl)
    {
        //curl方式访问URL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $durl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 获取数据返回   
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, true); // 在启用 CURLOPT_RETURNTRANSFER 时候将获取数据返回 
        $r = curl_exec($ch);
        curl_close($ch);
        return $r;
    }

    function getTxtcontent($txtfile)
    {
        /*
        * 逐行读取TXT文件 把内容存到数组中
        */

        $file = @fopen($txtfile, 'r');
        $content = array();
        if (!$file) {
            return 'file open fail';
        } else {
            $i = 0;
            while (!feof($file)) {
                $content[$i] = fgets($file);
                $i++;
            }
            fclose($file);
            $content = array_filter($content); //数组去空
        }
        return $content;
    }

    function ProduceTable($file_array, $sep)
    {
        /*
 * 把数组中的内容循环输出到表格里，表格每行内容为序列比对结果中的第5行后的内容
 * $file_array:传入数组参数
 * $sep:传入每行的分隔符参数
 */

        $i = 5;
        while ($i <= sizeof($file_array)) {
            echo "<tr>";
            @$row_content = explode($sep, $file_array[$i]);

            foreach ($row_content as $value) {
                //输出整个数组的内容            
                echo "<th>" . $value . "</th>";
            }

            echo "</tr>";
            $i++;
        }
    }
    ?>

</head>

<body class="home blog">

    <header id="header" class="main-header">

        <div class="wrapper">
            <div class="align-content align-center tab-block">
                <div class="col-left">
                    <div class="site-title">
                        <h1><a href="" rel="home">RESULT</a></h1>
                        <p>This is a public database for CBM researchers</p>
                    </div>
                    <!-- 页面整体布局-->
                </div><!-- col-left -->
                <div class="col-right">
                    <nav id="main-navigation" class="site-navigation primary-navigation sitenav" role="navigation">
                        <div class="menu-primary-menu-container">
                            <ul id="menu-primary-menu" class="menu">
                                <li id="menu-item-39" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-39"><a href="http://cbmdb.org.cn/" aria-current="page">HOME</a></li>
                            </ul>
                            <!--
                            <div id="sidebar">
                                <aside id="search-2" class="widget widget_search">
                                    <form role="search" method="get" class="search-form" action="http://ip/www/mywpproject/">
                                        <label>
                                            <input type="search" class="search-field" placeholder="Search..." value="" name="s">
                                        </label>
                                        <input type="submit" class="search-submit" value="Search">
                                    </form>
                                </aside>
                            </div>
                                    -->
                        </div>
                    </nav>
                </div><!-- col-right -->
            </div><!-- align content -->
        </div><!-- wrapper -->

    </header><!-- header -->
    <table class="result_table">
        <h2>
            <?php
            $SEQfasta = $_GET['SEQ'];
            $PDB_search_threshold = 1;
            //$BlastType = $_GET['radio_1']; //要改
            $random = mt_rand(1, 10000);
            $myfile = fopen("pathwww/filestore/hmmsubmit01.fasta", "w");
            fwrite($myfile, $SEQfasta);
            fclose($myfile);

            exec("/data/software/hmmer/bin/hmmscan  --pfamtblout pathwww/filestore/submitout01$random.txt  /data/www_data/database/Pfam/Pfam-A.hmm pathwww/filestore/hmmsubmit01.fasta"); # 执行hmmer的hmmscan
            exec("head -n -6 pathwww/filestore/submitout01$random.txt >> pathwww/filestore/out$random.txt");
            exec("head -n -6 pathwww/filestore/submitout01$random.txt >> pathwww/filestore/OutputFile$random.csv");
            //$seq = exec("sed -n '2p' pathwww/filestore/hmmsubmit01.fasta");
            //exec("cat pathwww/filestore/submitout01$random.txt | sed 's/\t/,/g;s/[[:space:]]//g' >pathwww/filestore/submitout01$random.csv");
            echo "<br>";

            $downloadUrl = 'http://ip/www/filestore/OutputFile' . $random . '.csv';
            echo "<a href='" . $downloadUrl . "' download='.csv' >Download result file</a>" . "<br>" . "<br>";
            echo "Overview of results" . "<br>";

            ?>
        </h2>

        <?php /*
        //读文件，初始化行号
        $filecontent = getTxtcontent($downloadUrl); //前五行是与数据库有关的内容
        $row_num = 0;

        //找分隔符
        $SepSet = getTxtcontent("http://ip/www/test02/submitout014092.txt");
        $sep = str_split($SepSet[5]); // 把字符串分割为单个字符
        //$row_content = explode($sep[10], $filecontent[5]); //用$filecontent[5]中的第十个字符做分隔符，分割$filecontent[5]
        $row_sep = $sep[10]; //设定比对结果正文每行的分隔符
        ?>

        <table border=1 cellspacing=0 align="center">
            <tr style="height: 50px;width: 50px;">
                <th style="height: 50px;;width: 50px;">Program</th>
                <th style="height: 50px;;width: 50px;">Description</th>
                <th style="height: 50px;;width: 50px;">Database</th>
                <th style="height: 50px;;width: 50px;">Fields</th>
                <th style="height: 50px;;width: 50px;">hits</th>
    </div>
    </tr>

    <tr>
        <?php
        while ($row_num < 5) {
            if (substr($filecontent[$row_num], 0, 10) === "# Database") {
                $filecontent[$row_num] = "CBMDB";
                echo "<th>" . $filecontent[$row_num] . "</th>";
                $row_num++;
            } elseif (substr($filecontent[$row_num], 0, 7) === "# Query") {
                $strcontent = explode(":", $filecontent[$row_num]);
                echo "<th>" . $strcontent[1] . "</th>";
                $row_num++;
            } elseif (substr($filecontent[$row_num], 0, 8) === "# Fields") {
                $strcontent = explode(":", $filecontent[$row_num]);
                echo "<th>" . $strcontent[1] . "</th>";
                $row_num++;
            } else {
                echo "<th>" . substr($filecontent[$row_num], 1) . "</th>";
                $row_num++;
            }
        }
 */
 ?>


        <div class="result">
            <?php
            echo "<iframe id='myIframe' src='http://ip/www/filestore/out$random.txt' style='width:1400px; height:480px; border:none; font-size: 1550px;'></iframe>"

            ?>
        </div>

        <?php //ProduceTable($filecontent, $row_sep); ?>

        </table>
        <!--========底部版权========-->

        <script type='text/javascript' id='medex-lite-navigation-js-extra'>
            var NavigationScreenReaderText = [];
        </script>
        <script type='text/javascript' src='http://ip/www/mywpproject/wp-content/themes/medex-lite/js/navigation.js?ver=20190715' id='medex-lite-navigation-js'></script>
        <script type='text/javascript' src='http://ip/www/mywpproject/wp-includes/js/wp-embed.min.js?ver=5.7.2' id='wp-embed-js'></script>
        <!--========/底部版权========-->

</body>

</html>